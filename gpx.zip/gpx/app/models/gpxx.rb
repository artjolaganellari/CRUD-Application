class Gpxx < ApplicationRecord
end
