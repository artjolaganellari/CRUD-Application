class GpxxesController < ApplicationController
  def index
	@gpxxes = Gpxx.all
  end

  def show
    @gpxx = Gpxx.find(params[:id])

  end

  def new
    @gpxx = Gpxx.new
   
  end

  def create
    gpxx = Gpxx.create(gpxx_params)
    redirect_to gpxxes_path, notice: "Created GPX track"
  end

  private 
  def gpxx_params
     params.require(:gpxx).permit(:name, :startdate)
  end 

  end
