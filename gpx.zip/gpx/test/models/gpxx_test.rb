require "test_helper"

class GpxxTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
