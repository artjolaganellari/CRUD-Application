require "test_helper"

class GpxxesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get gpxxes_index_url
    assert_response :success
  end

  test "should get show" do
    get gpxxes_show_url
    assert_response :success
  end

  test "should get new" do
    get gpxxes_new_url
    assert_response :success
  end

  test "should get edit" do
    get gpxxes_edit_url
    assert_response :success
  end
end
